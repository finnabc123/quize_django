from django.apps import AppConfig


class QuizAppConfig(AppConfig):
    name = 'quiz_app'
